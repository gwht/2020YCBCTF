#!/bin/bash

python3.6 /home/soc/task.py
