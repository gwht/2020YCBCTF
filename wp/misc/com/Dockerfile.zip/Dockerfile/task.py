# -*- coding:utf8 -*-
import socketserver
import os
import numpy
import random
import signal
from secret import flag


class Task(socketserver.BaseRequestHandler):
    
    def gen_chall(self):
        A = numpy.random.randint(2**10,size=(35,35))
        A = numpy.mat(A)
        B = numpy.random.randint(2**10,size=(35))
        res = B
        B = numpy.mat(B).transpose()
        C = A * B
        return A, C.transpose(), res

    def dosend(self, msg):
        self.request.sendall(msg)

    def handle(self):
        signal.alarm(120)
        self.dosend(b'If you want some scores, you\'ve got the right place.\n')
        self.dosend(b'   [1] Sign in.\n')
        self.dosend(b'   [2] Quit.\n')
        while True:
            self.dosend(b'[>] Please input your option: ')
            op = self.request.recv(10).strip()
            if op == b'1':
                MA, MC, Mres = self.gen_chall()
                for i in range(35):
                    for j in range(35):
                        self.dosend((str(MA[i,j]) + ' ').encode())
                    self.dosend((str(MC[0,i]) + '\n').encode())
                self.dosend(b'[>] Give me your cert in list format: ')
                Rres = self.request.recv(2048).decode()
                Rres = Rres.strip().strip('[').strip(']').split(', ')
                for i in range(len(Rres)):
                    Rres[i] = int(Rres[i])
                print(Rres)
                print(list(Mres))
                if Rres == list(Mres):
                    self.dosend(b'Good!\n')
                    self.dosend(flag.encode())
                    break
                else:
                    self.dosend(b"Invalid Cert.\n")
                    break

            else:
                self.dosend(b"GoodBye~\n")
                return False
        self.request.close()

class ForkedServer(socketserver.ForkingTCPServer, socketserver.TCPServer):
    pass


if __name__ == '__main__':
    HOST, PORT = '0.0.0.0', 80
    server = ForkedServer((HOST, PORT), Task)
    server.allow_reuse_address = True
    server.serve_forever()


