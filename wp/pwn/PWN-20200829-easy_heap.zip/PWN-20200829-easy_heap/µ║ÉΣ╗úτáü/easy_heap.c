#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/prctl.h>
#include <linux/filter.h>
//#include <seccomp.h>
#include <linux/seccomp.h>

char *chunk[0x100];
char temp[0x100];
int size[0x100];
int super_edit_time = 0;

void set_secommp(){
    prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
    struct sock_filter sfi[] ={
        {0x20,0x00,0x00,0x00000004},
        {0x15,0x00,0x05,0xc000003e},
        {0x20,0x00,0x00,0x00000000},
        {0x35,0x00,0x01,0x40000000},
        {0x15,0x00,0x02,0xffffffff},
        {0x15,0x01,0x00,0x0000003b},
        {0x06,0x00,0x00,0x7fff0000},
        {0x06,0x00,0x00,0x00000000}
    };
    struct sock_fprog sfp = {8, sfi};
    prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &sfp);
}

void init(){
    setvbuf(stdin,0,2,0);
    setvbuf(stdout,0,2,0);
    setvbuf(stderr,0,2,0);
	set_secommp();
    return ;
}
int read_int(){
    char buf[8];
    read(0,&buf,8);
    return atoi(&buf);
}
/*
void my_read(char *buf,int len){
	memset(temp,0,len);
    read(0,temp,len);
    strcpy(buf,temp); //这里可以造一个off-by-null
    return ;
}
*/
void menu(){
    puts("----Welcome --------");
    puts("1.Take a card");
    puts("2.Edit");
    puts("3.Drop a card");
	puts("4.Take a view");
    puts("5.Exit");
    printf("Choice:");
}
void add(){
    int i = 0;
    for (; i < 0x100 && chunk[i]; i++)
        ;
    printf("Size: ");
    size[i] = read_int();
    chunk[i] = malloc(size[i]); 
    if(chunk[i]){
        // puts("Content: ");
        // chunk[read(0,chunk[i],size[i])] = 0; //off-by-null
        puts("[+]Done!");
    }
    else
    {
        puts("[!]Something Wrong!");
        exit(0);
    }
    
}

void edit(){
    printf("Index: ");
    unsigned int idx = read_int();
    if (idx < 0x100 && chunk[idx])
    {
        puts("Content: ");
        chunk[idx][read(0,chunk[idx],size[idx])] = 0; //here off by one 
        puts("[+]Done!");
    }
	else{
		puts("Don not exist!");
	}
    
}

void delete(){
    printf("Index: ");
    unsigned int idx = read_int();
    if (idx < 0x100)
    {
        if (chunk[idx])
        {
            free(chunk[idx]);
            chunk[idx] = 0;
            size[idx] = 0;
            puts("[+]Done!");
        }
    }
}

void show(){
	printf("Index: ");
	unsigned int idx = read_int();
	if (idx < 0x100 && chunk[idx]){
		printf("Content: ");
		write(1,chunk[idx],strlen(chunk[idx]));
		puts("[+]Done!");
	}
	else{
		puts("Don not exist!");
	}
}

int main(){
    init();
    while (1)
    {
        menu();
        int choice = read_int();
        switch (choice)
        {
        case 1:
            add();
            break;
        case 2:
            edit();
            break;
        case 3:
            delete();
            break;
        case 4:
            show();
			break;
		case 5:
			puts("bye bye!");
			exit(0);
        }
    }
    
    return 0;
}


