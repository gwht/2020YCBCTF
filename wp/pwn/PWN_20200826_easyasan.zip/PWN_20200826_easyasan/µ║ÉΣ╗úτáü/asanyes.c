#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<unistd.h>
#include<string.h>
#include <uuid/uuid.h>


typedef struct {
    uuid_t userID;
    char username[0x28];
    char password[0x20];
    int flag;;
}user;

typedef struct{
    uuid_t *userID;
    char flag;
    char lock;
}token;


typedef struct{
    char *name;
    int size;
    char path[20];
    char buffer[];
}file;


user *User;
token *Token;
char enc_pwd[] = "2100122107654100";
file *fileList[5];
int count=0;
char basedir[20] = "/tmp/";


void logo(){

    printf(" ██████╗ ██╗    ██╗██╗  ██╗████████╗\n");
    printf("██╔════╝ ██║    ██║██║  ██║╚══██╔══╝\n");
    printf("██║  ███╗██║ █╗ ██║███████║   ██║  \n");
    printf("██║   ██║██║███╗██║██╔══██║   ██║  \n");
    printf("╚██████╔╝╚███╔███╔╝██║  ██║   ██║   \n");
    printf(" ╚═════╝  ╚══╝╚══╝ ╚═╝  ╚═╝   ╚═╝   \n\n");

}


void init()
{
    setvbuf(stdin,0,2,0);
	setvbuf(stdout,0,2,0);
	setvbuf(stderr,0,2,0);
    alarm(0x60);
    logo();
    User = malloc(sizeof(user));
    Token = malloc(sizeof(token));
}

int read_int()
{
    char buf[4];
    read(0,buf,4);
    return atoi(buf);
}  


int safe_read(char *buf,int len)
{
    int i;
    for(i = 0; i <= len; i++)
    {
        read(0,(buf+i),1);
        if(buf[i] == 10)
        {
            return 0;
        }
    }
    return 0;

}

void safe_read2(char *buf)
{
    scanf("%s",buf);
}

void  encrypt(char *s)
{
    char key[] = "this is easy , right?\n";
    for(int i = 0; i < strlen(s);i++)
    {
        s[i] = s[i] ^ 3;
    }

}


int createFile()
{
    int fileSize;
    char *name_ptr;
    FILE *fp = NULL;

    //check user permission
    if(Token->flag == 1)
    {
        puts("you don't have permission to create file!");
        return -1;
    }

    if(count <= 4)
    {
        fileList[count] = malloc(sizeof(file) + 0x20);  
        name_ptr = malloc(0x20);
        printf("input file name:");
        //scanf("%s",name_ptr);
        safe_read2(name_ptr);
        printf("input file size:");
        //scanf("%d",&fileSize);
        fileSize = read_int();

        fileList[count]->name = name_ptr;
        strcpy(fileList[count]->path,basedir);
        if(fileSize > 0x20)
        {
            fileList[count]->size = 0x20;           
        }
        else
        {
            fileList[count]->size = fileSize;
        }



        strcat(fileList[count]->path,name_ptr);

        if(!access(fileList[count]->path,0))
        {
            printf("file already exists!\n");
            return -1;
        }
        
        printf("input file content:");
        safe_read(fileList[count]->buffer,fileList[count]->size);
        fp = fopen(fileList[count]->path,"a+");
        if(fp!=NULL)
        {
            fputs(fileList[count]->buffer,fp);
            puts("create success!");
            printf("file path %s\n",fileList[count]->path);
            fclose(fp);
        }
        else
        {
            puts("can't create file");
        }
        
        count++;
        return 0;
    }

}

void moveFile()
{
    puts("you can't move file");
}


int deleteFile()
{
    //check user permission
    char name[20];

    if(Token->flag == 1)
    {
        puts("you don't have permission to delete file!");
        return -1;
    }    

    printf("input file name:");
    //scanf("%s",name);
    safe_read2(name);

    for(int i = 0; i< count;i++)
    {
        if(!strcmp(fileList[i]->name,name))
        {
            int result = unlink(fileList[i]->path);
            if(!result)
            {
                printf("delete file success!\n");
                return 0;
            }
            else
            {
                printf("failed to delete file!\n");
                return -1;
            }
        }
    }

    printf("file doesn't exist!\n");
    return -1;

}


void *printFile_routine(char *name)
{
    char filename[20];
    char path[20];
    char content[50];
    int flag = 0;
    FILE *fp = NULL;
    strcpy(filename,name);

    if(Token->flag != 3)
    {
        puts("you don't have permission to print file!");
        pthread_exit(NULL);
    }

    if(strstr(name,"flag")){
        printf("no no no \n");
        printf("you can print the flag");
        pthread_exit(NULL);
    }


    for(int i = 0; i< count;i++)
    {
        if(!strcmp(fileList[i]->name,filename))
        {
            flag = 1;
        }
    }

    if(flag == 0)
    {
        printf("you only can print your file\n");
        pthread_exit(NULL);
    }

    Token->lock = 1;

    sleep(2u);

    strcpy(path,basedir);
    strcat(path,name);

    fp = fopen(path,"a+");

    if(fp)
    {
        fgets(content,50,(FILE *)fp);
        printf("file name : %s\n",name);
        printf("content:\n");
        printf("%s\n",content);
        fclose(fp);

    }
    else
    {
        printf("failed to open file!\n");
        printf("maybe you shuold try again!\n");
        pthread_exit(NULL);
    }

}


int secret()
{
    char oldpath[20];
    char newpath[20];

    printf("you found my secret!\n");
    if(Token->flag != 3)
    {
        puts("you don't have permission to use this!");
        return -1;
    }    

    if(Token->lock != 1)
    {
        puts("no no no ,something wrong!");
        return -1;
    }

    printf("input old path:");
    safe_read2(oldpath);
    printf("input new path:");
    safe_read2(newpath);

    int res = symlink(oldpath,newpath);
    if(!res)
    {
        printf("success!\n");
    }
    else
    {
        printf("faliure!\n");
    }

    return 0;

}

int userChange()
{
    if(Token->flag != 2)
    {
        puts("you don't have permission to change!");
        return -1;
    }     
    
    printf("user name:");
    safe_read(User->username,0x28);
    printf("user password:");
    safe_read(User->password,0x20);
    printf("done!\n");
    
    Token->flag = User->flag;
    return 0;
}

void login()
{
    int ch;
    uuid_t uuid;
    char str[36];
    char name[20];
    char password[30];


    printf("generate your uuid:");
    uuid_generate(User->userID);
    uuid_unparse(User->userID,str);
    Token->userID = &User->userID;
    printf("%s\n",str);

    printf("select login ways!\n");
    puts("1. anonymous");
    puts("2. authentication");
    puts("3. admin");

    ch = read_int();
    switch(ch)
    {
        case 1:
            puts("login with anonymous");
            User->flag = 1;
            Token->flag = 1;
            break;
        case 2:
            puts("username:");
            //scanf("%s",name);
            safe_read2(&name);
            if(!strcmp(name,"guest")){
                strcpy(User->username,name);
                puts("password:");
                //scanf("%s",password);
                safe_read2(password);
                encrypt(password);
                if(!strcmp(password,enc_pwd))
                {
                    puts("password correct!");
                    puts("login with guest");
                    User->flag = 2;
                    Token->flag = 2;
                }
                else
                {
                    puts("password wrong!");
                    puts("login at anonymous!");
                    User->flag = 1;
                    Token->flag = 1;
                }
            }
            else
            {
                puts("user doesn't exist");
                puts("you will login with anonymous!");
                User->flag = 1;
                Token->flag = 1;

            }
            break;
        case 3:
            puts("no no no ");
            puts("you are no admin");
            puts("you will login with anonymous");
            User->flag = 1;
            Token->flag = 1;
            break;
        default:
            puts("don't have this option");
            puts("you will login with anoymous");
            User->flag = 1;
            Token->flag = 1;
            break;
    }
    
}



void menu()
{
    puts("1. create file");
    puts("2. delete file");
    puts("3. print file");
    puts("4. move file");
    puts("5. userchange");
    puts("6. secret");
    puts("7. exit");

}

int main(int argc, char *argv[])
{
    pthread_t tid;
    init();
    login();
    
    while(1)
    {
        int choice = 0;
        menu();
        choice = read_int();
        if(choice == 1)
        {
            createFile();
            continue;
        }

        if(choice == 2)
        {
            deleteFile();
            continue;
        }

        if(choice == 3)
        {
            char filename[20];
            printf("input file name:");
            safe_read2(filename);
            int ret = pthread_create(&tid, NULL, printFile_routine, filename);
            if(ret != 0 )
            {
                printf("failed to create thread!");
                continue;
            }

            continue;
        }

        if(choice == 4)
        {
            moveFile();
            continue;
        }

        if(choice != 5)
        {
            if(choice == 666)
            {
                secret();
                continue;
            }

            if(choice = 7)
            {
                puts("bye~");
                exit(0);
            }
            else
            {
                puts("invalid option");
                continue;
            }
        }
        else
        {
            userChange();
            continue;
        }

    }
    
}