#include <stdio.h>
#include <stdint.h>
#include <sys/prctl.h>
#include <linux/seccomp.h>
#include <linux/filter.h>
void set_secommp(){
    prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
    struct sock_filter sfi[] ={
        {0x20,0x00,0x00,0x00000004},
        {0x15,0x00,0x05,0xc000003e},
        {0x20,0x00,0x00,0x00000000},
        {0x35,0x00,0x01,0x40000000},
        {0x15,0x00,0x02,0xffffffff},
        {0x15,0x01,0x00,0x0000003b},
        {0x06,0x00,0x00,0x7fff0000},
        {0x06,0x00,0x00,0x00000000}
    };
    struct sock_fprog sfp = {8, sfi};
    prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &sfp);
}
char *chunk[50];
int number = 0;
int flag = 0;
#define DELTA 0x76129bda
int main(int argc, const char **argv, const char **envp)
{
  int v3;
  init();
  set_secommp();
  while ( 1 )
  {
    while ( 1 )
    {
      menu();
      v3 = get_num();
      if ( v3 != 1 )
        break;
      add();
    }
    if ( v3 == 3 )
    {
      delete();
    }
    else if ( v3 == 2 )
    {
      if(!flag)
    {
    int n = 0x10;
    char kk[0x100];
    read_0(kk,n);
    uint32_t const k[4]= {0x33,0x12,0x78,0x24};
    xxtea(kk,n,k);
    write(1,kk,n);
    flag = 1;
    } 
    }
    else
    {
      exit(0);
    }
  }
}
int init()
{
  setvbuf(stdin, 0LL, 2, 0LL);
  setvbuf(stdout, 0LL, 2, 0LL);
  setvbuf(stderr, 0LL, 2, 0LL);
  return memset(chunk, 0, 0x50);
}
int add()
{
  int v0; 
  int v2; 
  int v3;
  printf("how long?");
  v2 = get_num();
  if(number<=9&&number>=0)
    {
      if(v2>0&&v2<=0x68)
      {
        chunk[number] = malloc(0x10);
        *(long long int*)(chunk[number]+8) = malloc(v2);
        read(0,*(long long int*)(chunk[number]+8),v2);
        ++number;
      }
      else
    {
      exit(0);
    }
    }
    else
    {
      exit(0);
    }  
}

void xxtea(uint8_t *v, int n, uint32_t const key[4])  
{  
    uint8_t y, z;
    uint32_t sum;  
    unsigned i, rounds, e;  
    if (n > 1)            //n作为加解密的选择，正数为加密，负数为解密
    {  
        rounds = 7 + 35/n; //轮转数的选择，是个特征值：6+52/n
        sum = 0;  
        z = v[n-1]; //先取出最后一个值  
        do  
        {  
            sum += DELTA;  //开始加密
            e = (sum >> 2) & 3;  //通过sum得到e，也是个特征值
            for (i=0; i<n-1; i++)  //轮转次数
            {  
                y = v[i+1];  //得到
                v[i] += (((z>>7^y<<3) + (y>>2^z<<5) - 0x21) ^ ((sum^y^0x57) + (key[(i&3)^e] ^ z)+0x3f));  
                z = v[i];
                //细细分析就会知道，首先通过v[n-1]和v[1]进行加密得到v[0]，然后通过v[0]和v[2]加密得到v[1]就会发现规律了：其实就是3个数为一组，通过左右两个数加密得到中间的数这里只会运算到v[n-2]
            }  
            y = v[0];  
            v[n-1] += (((z>>7^y<<3) + (y>>2^z<<5) - 0x21) ^ ((sum^y^0x57) + (key[(i&3)^e] ^ z)+0x3f));  
            z = v[n-1];//最后一个数v[n-1]的加密，拿到v[0]和v[n-2]进行加密得到,算法一样
        }  //第一轮结束，每个数都加密了一遍
        while (--rounds);   //执行rounds轮，加密完全
    }  
}
void delete()
{
  int v1;
  printf("which one?");
  v1 = get_num();
  if ( v1 > 10 || v1 < 0)
  {
    exit(0);
  }
  else
  {
    if(chunk[v1])
    {
      free(*(long long int*)(chunk[v1]+8));
    }
  }
}

int read_0(char *a1,int a2)
{
  int v3;
  char buf[10];
  int i = 0;
  for ( ; ; ++i )
  {
    v3 = i;
    if ( i >= a2 )
      break;
    read(0, buf, 1);
    if ( *buf == 10 )
      break;
    *(i + a1) = *buf;
  }
  return v3;
}
int get_num()
{
  int v3;
  char nptr[40];
  read_0(&nptr, 16LL);
  v3 = atoi(&nptr);
}
void menu()
{
  printf("wellcome to ctf");
  printf("your choice:");
}