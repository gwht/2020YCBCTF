#include <stdio.h>
#include <signal.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#define TIMEOUT 60


struct game{
	int vaild ;
	char *name ;
	char message[24] ;
};


struct game* list[10];
// unsigned long int magic = 0 ;
unsigned int count = 0 ;


void menu(){
	puts("");
	puts("1. Add");
	puts("2. View ");
	puts("3. Delete");
	puts("4. Exit");
	printf("Your choice : ");
}


int add(){
	struct game *newgame = NULL ;
	char *buf = NULL ;
	unsigned size =0;
	unsigned index ;
	if(count < 10){
		newgame = malloc(sizeof(struct game));
		memset(newgame,0,sizeof(struct game));
		printf("size of the game's name: \n");
		if(scanf("%u",&size)== EOF) exit(-1);
		buf = (char*)malloc(size);
		if(!buf){
			puts("Error !!");
			exit(-1);
		}
		printf("game's name:\n");
		read(0,buf,size);
		newgame->name = buf ;
		printf("game's message:\n");
		scanf("%23s",newgame->message);
		newgame->vaild = 1 ;
		for(index = 0 ; index < 10 ; index++ ){
			if(!list[index]){
				list[index] = newgame ;
				break ;
			}
		}
		count++ ;
		puts("Added!");
	}else{
		puts("Too much!!!");
	}
}

int view(){
	unsigned index ;
	if(!count){
		puts("Null!");
	}else{
		for(index = 0 ; index < 10 ; index++){
			if(list[index] && (list[index])->vaild){
				printf("Game[%u]'s name :%s",index,(list[index])->name);
				printf("Game[%u]'s message :%s\n",index,(list[index])->message);
			}
		}	
	}
}


int del(){
	unsigned int index ;
	if(!count){
		puts("Null!");
	}else{
		printf("game's index:\n");
		scanf("%d",&index);
		if(index < 0 ||index >= 10 || !list[index]){
			puts("index error!");
			return 0 ;
		}
		(list[index])->vaild = 0 ;
		free((list[index])->name);
		puts("Deleted!");
	}
}


int main(){
	setvbuf(stdout,0,2,0);
	setvbuf(stdin,0,2,0);
	puts("Welcome to this easy game.");
	puts("I think You can pwn it!");
	puts("......");
	puts("");
	int choice ;
	char buf[10];
	while(1){
		menu();
		read(0,buf,8);
		choice = atoi(buf);
		switch(choice){
			case 1:
				add();
				break ;
			case 2:
				view();
				break ;
			case 3:
				del();
				break ;
			case 4:
				puts("Bye ~");
				exit(0);
			default :
				puts("Invalid choice");
				break ;
		}

	}

}