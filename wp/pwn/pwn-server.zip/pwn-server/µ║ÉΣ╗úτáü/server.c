#include <stdio.h>
#include <strings.h>
#include <string.h>
#include <sys/ptrace.h>
#include <pthread.h> 

typedef struct value
{
    char * name;
    char * pwd;
    int num;
    unsigned long id;
    unsigned long flag;
}people;

people * bss_ptr[0x10]={0};

void de_ptrace()
{
    if (ptrace(PTRACE_TRACEME, 0, 0, 0) ==-1 )
    {
        printf("dai hentai! don't debug me!\n");
        exit(-1);
    }

}

void initial()
{
    de_ptrace();
    setvbuf(stdout, 0, 2, 0);
    setvbuf(stdin, 0, 1, 0);
    setvbuf(stderr, 0, 1, 0);
}

void time2exit()
{
    int num=3;
    while(num--)
    {
        sleep(1);
        printf(".");
    }
    puts("");
    exit(-1);
}

void print_page(char * buf ,char * ty)
{
    int len= strlen(buf);
    puts(">>:");
    printf("HTTP/1.1 200 OK\nDate: Mon Jun 6 06:06:06 2066\n");
    printf("Content-Length: %d\nContent-Type: %s\n\n<!DOCTYPE html><head><meta charset=\"utf-8\"><title>server-pwn</title></head>%s\n",len,ty,buf );
}

void page_404()
{
    char page[0x100]={0};
    sprintf(page, "<html><body><h1>%s</h1></body></html>", "Page Not Found");
    print_page(&page,"text/html");
}


void page_index()
{
    int result,len,pwdd,i =0;

    char page[0x200]={0};
    char id[0x200]={0};
    char pwd[0x200]={0};
    char str1[0x200]={0};
    char str2[0x200]={0};

    
    for (i = 0; i < 0x10; ++i)
    {
        if ( bss_ptr[i] )
        {
            result=1;
            break;
        }
    }
    if (result)
    {
        // tips to login
        page[sprintf(page, "<html><body><h1>please input your id and password</h1></body></html>")]=0;
        print_page(&page,"text/html");
        puts("<<:");
        read(0,id,0x200);
        puts("<<:");
        read(0,pwd,0x200);
        pwdd=atoi(pwd);
        // printf("your input:\nid:%s,pwd:%p\n",id, pwdd);
        // printf("bss_ptr :\nid:%s,pwd:%p\n",bss_ptr[i]->id, bss_ptr[i]->pwd);
        for (i = 0; i < 0x10; ++i)
        {
            if (!bss_ptr[i])
            {
                continue;
            }
            if ( !strcmp(bss_ptr[i]->id, id) && bss_ptr[i]->pwd== pwdd)
            {
                
                str1[sprintf(str1, "<h1>welcome! %s</h1><hr>",bss_ptr[i]->name)]=0;

                if (bss_ptr[i]->num<0)
                {
                    bss_ptr[i]->num=-bss_ptr[i]->num;
                }
                
                len =sprintf(page, "<body><html>%s<h2>your num is:</h2>%d</body></html>",str1, bss_ptr[i]->num);
                *(char *)(page+len)=0;

                if (bss_ptr[i]->num > len)
                {
                    bss_ptr[i]->num=len;

                }
                
                puts(">>:");
                printf("HTTP/1.1 200 OK\nDate: Mon Jun 6 06:06:06 2066\n");
                printf("Content-Length: %d\nContent-Type: text/html\n\n<!DOCTYPE html><head><meta charset=\"utf-8\"><title>server-pwn</title></head>%s\n",len);
                write(1,page,bss_ptr[i]->num);

                return ;
            }
        }

        //id or pwd error
        len =sprintf(page, "<html><body><h1>%s</h1></body></html>", "id or password error!");
        *(char *)(page+len)=0;
        print_page(&page,"text/html");

    }
    else
    {
        // tips to use POST
        int len =sprintf(page, "<html><body><h1>%s</h1></body></html>", "nothing in database, you should use POST to create~");
        *(char *)(page+len)=0;
        print_page(&page,"text/html");
    }

}

void change_string(char * str)
{
    while(*str)
    {
        if (*str==' '||*str=='\n')
        {
            *str=0;
        }
        str++;
    }
}
void post_req(char * buf ,char * ty)
{
    int len= strlen(buf);
    puts(">>:");
    printf("HTTP/1.1 200 OK\nDate: Mon Jun 6 06:06:06 2066\n");
    printf("Content-Length: %d\nContent-Type: %s\n\n{%s}",len,ty,buf );
}
void free_it()
{
    int v2; 
    do
    {
        v2=0;
        for ( int i = 0; i <= 15; ++i )
        {
            if ( bss_ptr[i] )
            {
                if ( bss_ptr[i]->pwd <= 0 )
                {
                    if ( !bss_ptr[i]->pwd && bss_ptr[i]->flag )
                    {
                        bss_ptr[i]->flag = 0;
                        free(bss_ptr[i]->name);
                    }
                }
                else
                {
                    --bss_ptr[i]->pwd;
                    bss_ptr[i]->flag = 1;
                    ++v2;
                }
            }
        }
        sleep(1);
    }
    while ( v2 );

    for ( int j = 0; j <= 15; ++j )
    {
        free(bss_ptr[j]);
        bss_ptr[j] = 0LL;
    }

}

void post_delete(char * buf)
{
    pthread_t newthread;
    if ( pthread_create(&newthread, 0LL, free_it, 0LL) )
    {
        post_req("Error, can not delete","text/plain");
    }
    else
    {
        post_req("Success, has delete all data","text/plain");
    }
}

void POST_cmd(char * buf)
{
    char page[0x200]={0};
    char key1[0x200]={0};
    char key2[0x200]={0};
    char key3[0x200]={0};
    char key4[0x200]={0};
    char value1[0x200]={0};
    char value2[0x200]={0};
    char value3[0x200]={0};
    char value4[0x200]={0};


    if (buf=strstr(buf,"cmd="))
    {
        // buf[0]=='c' && buf[1]=='m' && buf[2]=='d' && buf[3]=='='
        buf+=4;
        // puts("in POST_cmd");
        // printf("%s\n",buf );
        if (buf[0]=='a' && buf[1]=='d' && buf[2]=='d')
        {
            //add
            // puts("in POST_cmd add");
            buf+=4;
            // printf("add:%s\n",buf );
            //id=123&pwd=123&name=aaa&motto=aaaa Connection: keep-alive
            sscanf(buf,"%8[^=]=%32[^&]",key1,value1);
            change_string(value1);
            // printf("key1:%s,value1:%s\n",key1,value1);
            if (strcmp(key1, "id")|| !*(char *)value1)
            {
                post_req("Error key-value, it must be [id]","text/plain");
                time2exit();
            }

            buf=strchr(buf,'&');
            *buf=0;
            buf++;
            sscanf(buf,"%8[^=]=%32[^&]",key2,value2);
            change_string(value2);
            // printf("key2:%s,value2:%s\n",key2,value2);
            if (strcmp(key2, "pwd")|| !*(char *)value2)
            {
                post_req("Error key-value, it must be [pwd]","text/plain");
                time2exit();
            }

            buf=strchr(buf,'&');
            *buf=0;
            buf++;
            sscanf(buf,"%8[^=]=%32[^&]",key4,value4);
            change_string(value4);
            // printf("key4:%s,value4:%s\n",key4,value4);
            if (strcmp(key4, "num")|| !*(char *)value4)
            {
                post_req("Error key-value, it must be [num]","text/plain");
                time2exit();
            }

            buf=strchr(buf,'&');
            *buf=0;
            buf++;
            char *tmp;
            tmp =strchr(buf,'=');
            *tmp=0;
            tmp++;
            // sscanf(buf,"%8[^=]=%100[^&]",key3,value3);
            // change_string(tmp);
            strncpy(value3,tmp,0x30);
            // printf("key3:%s,value3:%s\n",key3,value3);
            // deal_name(&value3);

            if (strcmp(buf, "name") )
            {
                post_req("Error key-value, it must be [name]","text/plain");
                time2exit();
            }
            // printf("buf %s\n", buf);
            // printf("tmp %s\n", tmp);
            // printf("value3 %s\n", value3);
            // getchar();
          


            int i=0;
            for ( i = 0; i <= 15 && bss_ptr[i]; ++i )
            {
                if ( bss_ptr[i]->name && !strcmp(bss_ptr[i]->name, &value3) )
                {
                    bss_ptr[i]->pwd = atoi(&value2);
                    bss_ptr[i]->flag = 0;
                    post_req("Success,has change the pwd","text/plain");
                    return ;
                }
            }
            people *ptr;
            ptr=malloc(sizeof(struct value));
            int id_len=strlen(value1);
            int name_len=strlen(value3);
            
            // printf("id_len:%p,name_len:%p\n", id_len,name_len);
            ptr->id=malloc(id_len);
            ptr->name=malloc(0x50);
            ptr->num=atoi(value4);
            // printf("ptr->num%p\n", ptr->num);
            ptr->pwd= atoi(value2);
            ptr->flag = 0;
            strcpy(ptr->id,value1);
            strncpy(ptr->name,value3,0x30);
            
            bss_ptr[i]=ptr;
            post_req("Success,has create a user","text/plain");

        }
        else if (buf[0]=='d' && buf[1]=='e' && buf[2]=='l'&& buf[3]=='e'&& buf[4]=='t'&& buf[5]=='e')
        {
            //delete
            // puts("in POST_cmd delete");
            buf+=7;
            // printf("delete:%s\n",buf );
            post_delete(buf);

            
        }
        else
        {
            post_req("Error cmd","text/plain");
            time2exit();
        }
    }
    else
    {
        post_req("Error POST data format","text/plain");
        time2exit();
    }
}



int main_func()
{
    // de_ptrace();
    char *buf=malloc(0x200);
    char * args_ptr;
    char str1[0x200]={0};
    char str2[0x200]={0};
    char str3[0x200]={0};
    char *tmp;
    int result=0;

    memset(buf, 0, 0x200);
    printf("<<:\n");
    int len=read(0,buf,0x200);
    *(char*)(buf+len)=0;
    if (len<=0 || len >=0x200)
    {
        time2exit();
    }

    if (tmp=strstr(buf, "Connection: keep-alive") )
    {
        result = 1;
        // *(char*)(tmp-1)=0;
    }

    sscanf(buf, "%s %s %s ", &str1, &str2, &str3);
    // printf("%s:%s-%s-%s\n", buf,&str1, &str2, &str3);


    // GTE / index.html ? id=1&name=a \t\n Connection: keep-alive
    if ( !strcmp(&str1, "GET") && !strcmp(&str2, "/") )
    {
        if (!strcmp(&str3, "index.html"))
        {
                // puts("page_index()");
                page_index();
                
        }
        else
        {
            page_404();
            time2exit();
        }

    }


    //POST / index.html \t\ncmd=add&name=xxx&phone=34234234&address=asdasdasd Connection: keep-alive
    if ( !strcmp(&str1, "POST") && !strcmp(&str2, "/") )
    {
        if (!strcmp(&str3, "index.html"))
        {
            if (args_ptr=strstr(buf, "\t\n") )
            {
                // strstr(buf, "\t\n");
                // puts("POST_cmd(args_ptr)");
                // printf("args_ptr:%s\n",args_ptr );
                args_ptr += 2;
                // printf("args_ptr:%s\n",args_ptr );
                POST_cmd(args_ptr);
            }
            else
            {
                // puts("POST_err();");
                post_req("Error POST data format","text/plain");
                time2exit();
                
                
            }
        }
        else
        {
            page_404();
            time2exit();
        }

    }


    return result;

}

int main(int argc, char const *argv[])
{   
    initial();
    int times=15;
    int chance=0;
    for (int i = 0; i < times; ++i)
    {
        chance=main_func();
        if (chance==0)
        {
            // puts("no chance~");
            time2exit();
        }
    }
    return 0;
}