#flag="GWHT{cfa2b87b3f746a8f0ac5c5963faeff73}"
#第一部分
flag1=""
end=1182843538814603
for i in range(5):
   c=end%2020
   end=(end-c)/2020
   flag1+=chr(int(c))
print (flag1[::-1])

#第二部分
en=[0x3,0x25,0x48,0x9,0x6,0x84]
output=[101, 96, 23, 68, 112, 42, 107, 62, 96, 53, 176, 179, 98, 53, 67, 29, 41, 120, 60, 106, 51, 101, 178, 189, 101, 48]
k=0
flag2=""
for i in range(13):
    a1=chr(output[k]^en[i%6])
    a2=chr(output[k+1]^en[i%6])
    flag2+=a2
    flag2+=a1
    k+=2
print(flag2)

#第三部分
from z3 import *
flag3=""
flag = [Int('flag%d' % i) for i in range(8)]

s = Solver()
s.add(flag[0]*3 + flag[1]*2 + flag[2]*5 == 1003)
s.add(flag[0]*4 + flag[1]*7 + flag[2]*9== 2013)
s.add(flag[0]   + flag[1]*8 + flag[2]*2 == 1109)
s.add(flag[3]*3 + flag[4]*2 + flag[5]*5 == 671)
s.add(flag[3]*4 + flag[4]*7 + flag[5]*9== 1252)
s.add(flag[3]   + flag[4]*8 + flag[5]*2 == 644)


print(s.check())
model = s.model()
res = [ model[flag[i]].as_long() for i in range(6) ]

for i in res:
   flag3+=chr(i)
print (flag3)
