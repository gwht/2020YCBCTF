#include <stdio.h>
#include <string.h>

const char alphabet[] = {
	'A', 'B', 'C', 'D', 'E', 'F', 'G',
    'H', 'I', 'J', 'K', 'L', 'M', 'N',
    'O', 'P', 'Q', 'R', 'S', 'T',
    'U', 'V', 'W', 'X', 'Y', 'Z',
    'a', 'b', 'c', 'd', 'e', 'f', 'g',
    'h', 'i', 'j', 'k', 'l', 'm', 'n',
    'o', 'p', 'q', 'r', 's', 't',
    'u', 'v', 'w', 'x', 'y', 'z',
    '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
    '+', '/'};
    
char cmove_bits(unsigned char src, unsigned lnum, unsigned rnum) 
{
    src <<= lnum;
    src >>= rnum;
    return src;
}

int encode_one(const char *indata, int inlen, char *outdata, int *outlen)
{
	int ret = 0;
	if(indata == NULL || inlen == 0)
	{
		return ret = -1;
	}
	
	int i;
	int in_len = 0;
	int pad_num = 0;
	
	if(inlen % 3 != 0)
	{
		pad_num = 3 - inlen % 3;
	}
	in_len = inlen + pad_num;
	int out_len = in_len * 8 / 6;
	
	char *p = outdata;
	
	//encode 
	for(i = 0; i < in_len; i += 3)
	{
		int value = *indata >> 2;
		char c = alphabet[value];
		*p = c;
		
		if(i == inlen + pad_num - 3 && pad_num != 0)
		{
			if(pad_num == 1)
			{
				*(p + 1) = alphabet[(int)(cmove_bits(*indata, 6, 2) + cmove_bits(*(indata + 1), 0, 4))];
				*(p + 2) = alphabet[(int)cmove_bits(*(indata + 1), 4, 2)];
				*(p + 3) = '=';
			}
			else if(pad_num == 2)
			{
				*(p + 1) = alphabet[(int)cmove_bits(*indata, 6, 2)];
            	*(p + 2) = '=';
            	*(p + 3) = '=';
        	} 
		}
		else
        {
            *(p + 1) = alphabet[cmove_bits(*indata, 6, 2) + cmove_bits(*(indata + 1), 0, 4)];
            *(p + 2) = alphabet[cmove_bits(*(indata + 1), 4, 2) + cmove_bits(*(indata + 2), 0, 6)];
            *(p + 3) = alphabet[*(indata + 2) & 0x3f];
		}
		p += 4;
		indata += 3;
	}
	
	if(outlen != NULL)
	{
		*outlen = out_len;
	}
	return ret;
}

int encode_two(const char *indata, int inlen, char *outdata, int *outlen)
{
	int ret = 0;
	if(indata == NULL || inlen == 0)
	{
		return ret = -1;
	}
	
	/*
	1-1	1-3
	2-2	2-1
	3-3	3-4
	4-4	4-2
	*/
	char *p = outdata;
	strncpy(p,indata+26,13);
	strncpy(p+13,indata,13);
	strncpy(p+26,indata+39,13);
	strncpy(p+39,indata+13,13);
	
	return ret;
}

int encode_three(const char *indata, int inlen, char *outdata, int *outlen)
{
	int ret = 0;
	if(indata == NULL || inlen == 0)
	{
		return ret = -1;
	}
	
	char *p = outdata;
	for(int i = 0; i < inlen; i ++)
	{
		char c = *indata;
		int N = 3;
		if(c >= 'A' && c <= 'Z') *p = ((c - 'A') + N) % 26 + 'A';
		else if(c >= 'a' && c <= 'z') *p = ((c - 'a') + N) % 26 + 'a';
		else if(c >= '0' && c <= '9') *p = ((c - '0') + N) % 10 + '0';
		else *p = c;
		
		p ++;
		indata ++;
	}
	
	return ret;
}



int main(int argc, char** argv)
{
	char flag4[] = {"EmBmP5Pmn7QcPU4gLYKv5QcMmB3PWHcP5YkPq3=cT6QckkPckoRG"};
	char flag3[52];
	char flag2[52];
	char flag1[52];
	char flag[38];
	int L;
	printf("Hello, please input your flag and I will tell you whether it is right or not.\n");
	scanf("%38s", &flag);
	if(strlen(flag) == 38)
	{
		if(!encode_one(flag,strlen(flag),flag1,&L))
		{
			if(!encode_two(flag1,strlen(flag1),flag2,&L))
			{
				if(!encode_three(flag2,strlen(flag2),flag3,&L))
				{
					if(!strcmp(flag3,flag4))
					{
						printf("you are right!\n");
						return 0;
					}
				}

			}
		}
	}
	
	printf("Something wrong. Keep going.");
	return 0;
	
	
	
	
	
}

