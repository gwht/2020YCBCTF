<?php
if (isset($_GET['file'])) {
	if(preg_match('/#|base64|rot13|base32|base16/i', $_GET['file'])){
        	die('G0-OUT'.'<br>'.'hacker!');
        }

    require_once($_GET['file']);
} else {
    header('Location: /?file=GWHT.php');
}
