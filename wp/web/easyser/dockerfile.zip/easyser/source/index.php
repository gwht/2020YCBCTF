
<html>
<head>
     <style> div.main { margin-left:auto; margin-right:auto; width:80%; } body { background-color: 		#FAEBD7; }</style>
     <title>
       easyphp
     </title>
</head>
<body>
    <div class="main">
    <h1>Welcome to the YCB</h1>
    <p> Have fun!</p>
    <br>
</div>
    </body>
</html>

