
<html>
<head>
     <style> div.main { margin-left:auto; margin-right:auto; width:50%; } body { background-color:  #f5f5f0; }</style>
     <title>
        easyphp
     </title>
</head>
<body>
    <div class="main">
    <h2>本次比赛已和百度达成协议</h2>
    <h2>有不会的可以直接上百度搜</h2>
    <p> Have fun!</p>
    <br>
    <form method="GET" action="star1.php">
        <input type="text" value="https://www.baidu.com" name="path">
        <input type="submit" value="Submit">
    </form>
</div>
        <iframe src="https://www.baidu.com"  width=100% height=100% frameborder="0"></iframe>
    </body>
    <!--  小胖说用个不安全的协议从我家才能进ser.php呢！  !-->
</html>
<?php
    require_once('ser.php');
    error_reporting(0);
    $str = 'url error<br>';
    $filter1= '/^http:\/\/127\.0\.0\.1\//i';
    $filter2 = '/.?f.?l.?a.?g.?/i';
    $url=$_GET['path']; 
    $c=$_GET['c']; 
    if(!preg_match($filter1, $url)){
        die($str);
    }
    if (preg_match($filter2, $url)) {
        die("??");
    }
    
 
    $text = @file_get_contents($url, false);
    print($text);

    if(isset($c)){
        echo $x = unserialize($c);
    }
    else{
        echo "your hat is too black!";
    }
?>
